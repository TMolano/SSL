<?

class myclass{

public function myMethod(){

echo "Hello World";
	}

}


$mynewclass = new myclass();
$mynewclass->myMethod();

?>