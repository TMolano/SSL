<?

class login extends AppController{

  public function __construct($parent){

	$this->parent=$parent;
	
	}
	
	public function index(){
	
	
	$data = array();

$data["pagename"] = "login";
$data["navigation"] = $this->parent->getNav();

$random = substr( md5(rand()), 0, 7);
$data["cap"]=$random;

$this->parent->getView("header",$data);
$this->parent->getView("loginForm",$data);
$this->parent->getView("footer");

	}
	
	public function receiveForm(){
	
	$err = array();
	

if(!@$_POST["usercaptcha"] || $_POST["usercaptcha"]!= $_SESSION["usercaptcha"]){
array_push($err,"Captcha Incorrect");
}

if(count($err)>0){
header("location:/login?msg=".implode("&",$err));
	}
	
	else{
	
	$file = "./assets/upload.txt";
	$h = fopen($file, "r");
	$content = fread($h, filesize($file));
	$split = explode("|" , $content);
	fclose($h);	
	
if($_POST["username"] == $split[0] || $_POST["username"] == "Joe@aol.com"  && $_POST["password"] == "password"){
		
			$_SESSION["isloggedin"] = "1";
			$_SESSION["username"] = $_POST["username"];
			
			header("location:/profile");

		
		}
	else{
	
			$_SESSION["isloggedin"] = "0";
			$_SESSION["username"] = "";
			header("location:/login?msg=Invalid Login");
			
	
	}
	}
	
}

}?>