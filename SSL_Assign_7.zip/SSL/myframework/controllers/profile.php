<?

class profile extends AppController{

  public function __construct($parent){

	$this->parent=$parent;
	
	if(!@$_SESSION["isloggedin"] || @$_SESSION["isloggedin"]!="1"){
	
	header("location:/login?msg=You must be signed in to access this page.");}
	
	}
	
	public function index(){
	
	$data = array();
	$data["pagename"] = "profile";
	$data["navigation"] = $this->parent->getNav();	
	
	
	$file = "./assets/upload.txt";
	$h = fopen($file, "r");
	$content = fread($h, filesize($file));
	$split = explode("|" , $content);
	$_SESSION["split"] = $split;
	fclose($h);	
		
		
	$this->parent->getView("header", $data);
	$this->parent->getView("profile");
	$this->parent->getView("footer");
	}
	
	public function updatePicture(){
	
	if($_FILES["myfile"]["type"] == "text/plain" || $_FILES["myfiles"]["type"] == "text/plain"){
	
	
		if(move_uploaded_file($_FILES["myfile"]["tmp_name"], "./assets/".$_FILES["myfile"]["name"])){
	
		header("location:/profile?msg=Uploaded file.");
	
		}
		
		else{
		
		echo "problem uploading";
		
		}
	}
	
	else{
	
	header("location:/profile?msg=Only .txt files are allowed.");
	}
}

}

?>