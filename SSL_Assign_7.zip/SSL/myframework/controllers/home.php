<?

class home extends AppController{

  public function __construct($parent){

	$this->parent=$parent;
	
	}
	
	public function index(){
	
	
	$data["pagename"] = "home";
	$data["navigation"] = $this->parent->getNav();	
	
	
	$this->parent->getView("header", $data);
	$this->parent->getView("home");
	$this->parent->getView("footer");
	}
}

?>