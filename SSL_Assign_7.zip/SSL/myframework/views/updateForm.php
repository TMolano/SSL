  <!-- Page Content -->
  <div class="container">

    <!-- Page Heading/Breadcrumbs -->
    <h1 class="mt-4 mb-3">Crud
      <small>Subheading</small>
    </h1>

    <ol class="breadcrumb">
      <li class="breadcrumb-item">
      </li>
      
    </ol>

    <!-- Intro Content -->
    <div class="row">
      <div class="col-lg-6">
        <form action="/crud/update/<?echo $this->urlPathParts[2]?>" method="post">
        <h2>Update email</h2>
        <input type="text"  name="updateemail" value="<? echo $this->urlPathParts[2] ?>">
        <input type="submit">
        </form>
        
        
    </div>
    <!-- /.row -->

  </div>
  <!-- /.container -->