 
<!-- Page Content -->
<div class="container">
<!-- Page Heading/Breadcrumbs -->
	<h1 class="mt-4 mb-3">
		Login <small>Subheading</small> 
	</h1>
	<ol class="breadcrumb">
		<li class="breadcrumb-item"> <a href="index.html">Home</a> </li>
		<li class="breadcrumb-item">Login</li>
	</ol>
<!-- Intro Content -->
	<div class="row">
		<div class="col-lg-12">
		
<?

function create_image($cap)

{

unlink("./assets/image1.png");

global $image;

$image = imagecreatetruecolor(200, 50) or die("Cannot Initialize new GD image stream");

$background_color = imagecolorallocate($image, 255, 255, 255);

$text_color = imagecolorallocate($image, 0, 255, 255);

$line_color = imagecolorallocate($image, 64, 64, 64);

$pixel_color = imagecolorallocate($image, 0, 0, 255);

imagefilledrectangle($image, 0, 0, 200, 50, $background_color);

for ($i = 0; $i < 3; $i++) {

imageline($image, 0, rand() % 50, 200, rand() % 50, $line_color);

}

for ($i = 0; $i < 1000; $i++) {

imagesetpixel($image, rand() % 200, rand() % 50, $pixel_color);

}

$text_color = imagecolorallocate($image, 0, 0, 0);

ImageString($image, 22, 30, 22, $cap, $text_color); 

imagepng($image, "./assets/image1.png");

}

create_image($data["cap"]);

$_SESSION["usercaptcha"] = $data["cap"];

echo "<img src='/assets/image1.png'>";

?>
		<form method="post" action="/login/receiveForm">
		<div class="form-group input-group">
<div class="input-group-prepend">                
<span class=input-group-text"><i class="fa fa-user"></i></span>
</div>

<input name="usercaptcha" type="text" class="form-control" placeholder="captcha">

</div> 
			<div class="form-row">
			<!-- Username -->
				<div class="form-group input-group col-lg-12">
					<div class="input-group-prepend">
						<span class="input-group-text"><i class="fa fa-user"></i></span> 
					</div>
					<input id="username" name="username" type="text" class="form-control col-lg-4" placeholder="username"> 
				</div>
			<!-- Password -->
				<div class="form-group input-group col-lg-12">
					<div class="input-group-prepend">
						<span class="input-group-text"><i class="fa fa-user"></i></span> 
					</div>
					<input id="password" name="password" type="text" class="form-control col-lg-4" placeholder="password"> 
				</div>				
				<div class="form-group input-group">
					<input class="bg-success rounded" type="submit" value="Login"></a>
				</div>
			</form>
		</div>
	</div>
<!-- /.row -->
</div>
<!-- /.container -->
