  <!-- Page Content -->
  <div class="container">

    <!-- Page Heading/Breadcrumbs -->
    <h1 class="mt-4 mb-3">Crud
      <small>Subheading</small>
    </h1>

    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="/crud/addForm">Add New User </a>
      </li>
      
    </ol>

    <!-- Intro Content -->
    <div class="row">
      <div class="col-lg-6">
      <ul>
        <? 
    	
        foreach($data["users"] as $user){
        
        echo "<li>".$user["email"];
        echo " <a href='/crud/delete/".$user["id"]."'>Delete</a>";
        echo " | <a href='/crud/updateForm/".$user["email"]."'>Update</a></li>";
        
        }
        ?>
        </ul>
      </div>
    <!-- /.row -->

  </div>
  <!-- /.container -->