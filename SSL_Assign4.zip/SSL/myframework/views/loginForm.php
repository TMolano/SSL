 
<!-- Page Content -->
<div class="container">
<!-- Page Heading/Breadcrumbs -->
	<h1 class="mt-4 mb-3">
		Login <small>Subheading</small> 
	</h1>
	<ol class="breadcrumb">
		<li class="breadcrumb-item"> <a href="index.html">Home</a> </li>
		<li class="breadcrumb-item">Login</li>
	</ol>
<!-- Intro Content -->
	<div class="row">
		<div class="col-lg-12">
			<form method="post" action="/login/receiveAjax">
			<div class="form-row">
			<!-- Username -->
				<div class="form-group input-group col-lg-12">
					<div class="input-group-prepend">
						<span class="input-group-text"><i class="fa fa-user"></i></span> 
					</div>
					<input id="username" name="username" type="text" class="form-control col-lg-4" placeholder="username"> 
				</div>
			<!-- Password -->
				<div class="form-group input-group col-lg-12">
					<div class="input-group-prepend">
						<span class="input-group-text"><i class="fa fa-user"></i></span> 
					</div>
					<input id="password" name="password" type="text" class="form-control col-lg-4" placeholder="password"> 
				</div>				
				<div class="form-group input-group">
					<input class="bg-success rounded" type="submit" onclick="Ajaxsubmit()" value="Login"></a>
				</div>
			</form>
		</div>
	</div>
<!-- /.row -->
</div>
<!-- /.container -->
