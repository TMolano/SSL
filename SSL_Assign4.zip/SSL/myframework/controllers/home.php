<?

class home extends AppController{

  public function __construct($parent){

	$this->parent=$parent;
	
	}
	
	public function index(){
	
	$data = array();
	$data["pagename"] = "home";
	$data["navigation"] = array("home"=>"/home", "about"=>"/about", "progress"=>"/progress", "register"=>"/register", "login"=>"/login");
	
	
	
	$this->parent->getView("header", $data);
	$this->parent->getView("home");
	$this->parent->getView("footer");
	}
}

?>