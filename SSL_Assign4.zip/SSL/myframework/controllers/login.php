<?

class login extends AppController{

  public function __construct($parent){

	$this->parent=$parent;
	
	}
	
	public function index(){
	
	$data = array();
	$data["pagename"] = "login";
	$data["navigation"] = array("home"=>"/home", "about"=>"/about", "progress"=>"/progress", "register"=>"/register", "login"=>"/login");
	
	
	
	$this->parent->getView("header", $data);
	$this->parent->getView("loginForm");
	$this->parent->getView("footer");
	}
	
	public function receiveAjax(){
	
		if($_POST["username"] == "username" && $_POST["password"] == "password"){
		
		echo "valid";
		
		}
		
		else if($_POST["username"] == "" && $_POST["password"] == ""){
		
		echo "blank";
		
		}
		
		else {echo "invalid";
		}
		
	}

}

?>