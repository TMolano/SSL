<html>
<style>
.link{
	color: blue;
	font-size: 1.5rem;
	text-decoration: none;
	}
	
.active{
background: gold;
}
	
.link:hover{
color: cyan;}
	
h1{
	font-style: italic;
	text-align: center;
	padding: 5rem;
	border: 1px solid black;
	}
</style>

<?

//var_dump($this);

foreach($data["navigation"] as $key => $link){

	if($key == $this->urlPathParts[0]){

		echo "<a class='link active' href='".$link."'>".strtoupper($key)."</a> | ";

	}

else echo "<a class='link' href='".$link."'>".strtoupper($key)."</a> | ";
	

}
  
?>
 <h1>Header</h1>

</html>