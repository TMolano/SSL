<?php

echo "Hello from PHP"

?>