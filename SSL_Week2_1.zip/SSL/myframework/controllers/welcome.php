<?

class welcome extends AppController{

  public function __construct($parent){

	$this->parent=$parent;
	var_dump($this->parent);
	}
	
	public function welcome(){
	
	//echo "Welcome";
	
	$data = array();
	$data["pagename"] = "welcome";
	$data["navigation"] = array("home"=>"/home", "about"=>"/about");
	
	$this->parent->getView("header", $data);
	$this->parent->getView("body");
	$this->parent->getView("footer");
	}
	
}

?>