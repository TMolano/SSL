 
<!-- Page Content -->
<div class="container">
<!-- Page Heading/Breadcrumbs -->
	<h1 class="mt-4 mb-3">
		Register <small>Subheading</small> 
	</h1>
	<ol class="breadcrumb">
		<li class="breadcrumb-item"> <a href="index.html">Home</a> </li>
		<li class="breadcrumb-item">Register</li>
	</ol>
<!-- Intro Content -->
	<div class="row">
		<div class="col-lg-12">
			<form method="post" action="/register/registeraction">
			<div class="form-row">
			<!-- Name -->
				<div class="form-group input-group col-lg-4">
					<div class="input-group-prepend">
						<span class="input-group-text"><i class="fa fa-user"></i></span> 
					</div>
					<input required name="name" type="text" class="form-control" placeholder="Name"> 
				</div>
			<!-- Email -->
				<div class="form-group input-group col-lg-4">
					<div class="input-group-prepend">
						<span class="input-group-text"><i class="fa fa-user"></i></span> 
					</div>
					<input required name="email" type="text" class="form-control" placeholder="Email"> 
				</div>
			<!-- Area of Study -->
				<div class="form-group input-group col-lg-4">
					<div class="input-group-prepend">
						<span class="input-group-text"><i class="fa fa-user"></i></span> 
					</div>
					<select name="study" type="text" class="form-control">
						<option value="" disabled selected hidden>Area of Study</option>
						<option value="IT">IT</option>
						<option value="Music">Music</option>
						<option value="Radio">Radio</option>
						<option value="Gaming">Gaming</option>
					</select>
				</div>
			<!-- Subscribe -->
				<div class="form-group input-group form-check">
					<input name="subscribe" type="checkbox" class="form-check-input" id="sub" value="yes"> 
					<label for="sub" class="form-check-label">Subscribe to our mailing list</label> 
				</div>
	
			<!-- Male -->
				<div class="form-group input-group form-check form-check-inline">
					<input required name="gender" type="radio" class="form-check-input" id="male" value="male"> 
					<label for="male" class="form-check-label">Male</label> 
				</div>
			<!-- Female -->
				<div class="form-group input-group form-check form-check-inline">
					<input name="gender" type="radio" class="form-check-input" id="female" value="female"> 
					<label for="female" class="form-check-label">Female</label> 
				</div>
			
			<!-- Message -->
				<div class="form-group input-group form-check form-check-inline">
					<label for="message" class="form-check-label col-12">How did you hear about us?</label> 
					<textarea name="message" type="textarea" class="form-control form-check-input col-6" rows="6" id="message"></textarea>
				</div>
				</div>
				
				<div class="form-group">
					<input type="submit" class="btn btn-primary btn-block" value="Submit" />
				</div>
			</form>
		</div>
	</div>
<!-- /.row -->
</div>
<!-- /.container -->
