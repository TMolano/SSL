<?

class logout extends AppController{

  public function __construct($parent){

	$this->parent=$parent;
	
	
	$_SESSION["isloggedin"] = 0;
	session_destroy();
	header("location:login"); 
	}
	
	public function index(){
	
	$data = array();
	$data["pagename"] = "about";
	$data["navigation"] = array("home"=>"/home", "about"=>"/about", "progress"=>"/progress", "register"=>"/register", "login"=>"/login");
	$this->parent->getView("header", $data);
	$this->parent->getView("about");
	$this->parent->getView("footer");
	}
}

?>