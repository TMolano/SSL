<?

class progress extends AppController{

  public function __construct($parent){

	$this->parent=$parent;
	
	if(!@$_SESSION["isloggedin"] || @$_SESSION["isloggedin"]!="1"){
	
	header("location:/login?msg=You must be signed in to access this page.");}
	
	}
	
	public function index(){
	
	
	
	$data = array();
	$data["pagename"] = "progress";
	$data["navigation"] = array("home"=>"/home", "about"=>"/about", "progress"=>"/progress", "register"=>"/register", "login"=>"/login");
	
	
	
	$this->parent->getView("header", $data);
	$this->parent->getView("progress");
	$this->parent->getView("footer");
	}
}

?>