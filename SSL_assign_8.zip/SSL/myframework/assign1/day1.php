<html><h1>TEST</h1>
<?php

/*
multi
*/

//single

$name = "trevor";

$arr = array("name"=>"trevor");

foreach($arr as $key => $value) {
echo $key;
}

?>
</html>