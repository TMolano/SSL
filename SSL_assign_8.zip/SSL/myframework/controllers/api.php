<? 

class api extends AppController{

	public function __construct($parent){
	
	$this->parent = $parent;

	
	}
	
	public function index(){
	
	$data["pagename"] = "api";
	$data["navigation"] = $this->parent->getNav();	
	
	$this->parent->getView("header", $data);
	$this->parent->getView("api", $data);
	$this->parent->getView("footer");
	
	}

	public function showApi(){
	
	//$this->getView("header", array("pagename"=>"api"));
	$data = $this->parent->getModel("apiModel")->googleBooks($_REQUEST["searchBook"]);
	
	$this->getView("header", $data);
	$this->getView("api", $data);
	$this->getView("footer");
	
	}
	
	
	
	public function add(){
	
	if (!isset($_SESSION['bookList'])){
	$_SESSION["bookList"] = array();
	var_dump($_SESSION["bookList"]);
	}
	
	$title = $this->parent->urlPathParts[2];
	
	$_SESSION["bookList"][] = str_replace("%20"," ", $title);
	

	var_dump($_SESSION["bookList"]);
	
	header("location:/api");
		
		
	}
	
	public function delete(){
	
	$index = $this->parent->urlPathParts[2];
	unset($_SESSION["bookList"][$index]);
	

	header("location:/profile");
	
	}
	
}

?>