<?

class crud extends AppController{

  public function __construct($parent){

	$this->parent=$parent;
	
	}
	
	public function index(){
	
	
	$data["pagename"] = "crud";
	$data["navigation"] = $this->parent->getNav();	
	
	$sql = "select * from users";
	$data["users"] = $this->parent->getModel("users")->select($sql);
	
	
	$this->parent->getView("header", $data);
	$this->parent->getView("crud", $data);
	$this->parent->getView("footer");
	}
	
	
	public function addForm(){
	
	
	$data["pagename"] = "crud";
	$data["navigation"] = $this->parent->getNav();
	
	$this->parent->getView("header", $data);
	$this->parent->getView("addForm");
	$this->parent->getView("footer");
	
	}
	
	public function updateForm(){
	
	
	$data["pagename"] = "crud";
	$data["navigation"] = $this->parent->getNav();
	
	
	$this->parent->getView("header", $data);
	$this->parent->getView("updateForm", $data);
	$this->parent->getView("footer");
	
	}
	
	public function addAction(){
	
	
	$sql = "insert into users (email, password) values (:email, :password)";
	$data["users"] = $this->parent->getModel("users")->insert($sql, 
	array(":email"=>$_REQUEST["useremail"], ":password"=>sha1($_REQUEST["userpass"])));
	
	header("location:/crud");
	
	}
	
	public function delete(){
	
	
	$sql = "delete from users where id = :id";
	$data["users"] = $this->parent->getModel("users")->delete($sql, 
	array(":id"=>$this->parent->urlPathParts[2]));
	
	
	header("location:/crud");
	
	}
	
	public function update(){
	
	$err = array();

	if(empty($_POST["updateemail"]) || $_POST["updateemail"]==""){
		
		array_push($err, "Email field is blank");
		
		
		}
		
		else{
		
			if(!preg_match("/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/" , $_POST["updateemail"])){
			
			array_push($err, "Email format must be valid");
			
			}
			
			if(count($err) > 0) {
		
		header("location:/crud?msg=".implode("&", $err));}
		
		else { 
		
	$sql = "update users set email = :newemail, password = :newpassword where id = :id";
	$data["users"] = $this->parent->getModel("users")->update($sql, 
	array(":newemail"=>$_REQUEST["updateemail"], ":newpassword"=>sha1($_REQUEST["updatepass"]), ":id"=>$this->parent->urlPathParts[2]));
	
	header("location:/crud");
	
			}
		}
	
	}

}

?>