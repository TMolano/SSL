<?

class register extends AppController{

  public function __construct($parent){

	$this->parent=$parent;
	
	}
	
	public function index(){
	
	$data = array();
	$data["pagename"] = "register";
	$data["navigation"] = $this->parent->getNav();
	$this->parent->getView("header", $data);
	$this->parent->getView("registerForm");
	$this->parent->getView("footer");
	}
	
	public function registerConfirmed(){
	
	$data = array();
	$data["pagename"] = "register";
	$data["navigation"] = $this->parent->getNav();
	$this->parent->getView("header", $data);
	$this->parent->getView("registerConfirmed");
	$this->parent->getView("footer");
	
	
	}
	
	public function registerAction(){
	
	
	$err = array();
	
	
		if(empty($_POST["name"]) || $_POST["name"]==""){
		
		array_push($err, "Name field is blank");
		
		}
		
		else{
		
			if(!preg_match("/^[a-zA-Z]+(([\'\,\.\- ][a-zA-Z ])?[a-zA-Z]*)*$/" , $_POST["name"])){
			
			array_push($err, "Name must only contain letters");
			
			}
			
		
		}
		
		//------------
		
		if(empty($_POST["email"]) || $_POST["email"]==""){
		
		array_push($err, "Email field is blank");
		
		}
		
		else{
		
			if(!preg_match("/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/" , $_POST["email"])){
			
			array_push($err, "Email format must be valid");
			
			}
			
		
		}
		
		//------------
		
		if(empty($_POST["gender"]) || $_POST["gender"]==""){
		
		array_push($err, "No gender is selected");
		
		}
		
		
		if(count($err) > 0) {
		
		header("location:/register?msg=".implode("&", $err));}
		
		else { header("location:/register/registerConfirmed");}
		
		
		
		
		
	
	}
	
}

?>