<?

class progress extends AppController{

  public function __construct($parent){

	$this->parent=$parent;
	
	if(!@$_SESSION["isloggedin"] || @$_SESSION["isloggedin"]!="1"){
	
	header("location:/login?msg=You must be signed in to access this page.");}
	
	}
	
	public function index(){
	
	
	
	
	$data["pagename"] = "progress";
	$data["navigation"] = $this->parent->getNav();
	
	
	$this->parent->getView("header", $data);
	$this->parent->getView("progress");
	$this->parent->getView("footer");
	}
}

?>