<div class="container"> 


	<div class="starter-template"</div>
	<h1>Book API Search</h1>
	
	<form method="post" action="/api/showApi"> 
	
	<input type="text" name="searchBook" id="searchBook" placeholder="ex: title, author...">
	<input type="submit" value="search">
	
	</form>
	
	<? 
	 
	 
	if (empty($_REQUEST['searchBook'])){
	
	
	
	}
	
	else{
	
	 foreach ($data as $item){
	 
	 	echo "<li>".$item["volumeInfo"]["title"];
	 	echo " <a href='/api/add/".$item["volumeInfo"]["title"]."'>Add</a></li>";
	 
	 }
	 
	 }
	
	?>

	</div>
	

</div><!-- container -->