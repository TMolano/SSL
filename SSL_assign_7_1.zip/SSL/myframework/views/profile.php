 
<!-- Page Content -->
<div class="container">
<!-- Page Heading/Breadcrumbs -->
	<h1 class="mt-4 mb-3">
		Profile 
		<small>
			Subheading 
		</small>
	</h1>
	<ol class="breadcrumb">
		<li class="breadcrumb-item">
			<a href="index.html">
				Home 
			</a>
		</li>
		<li class="breadcrumb-item">
			Profile 
		</li>
	</ol>
<!-- Intro Content -->
	<div class="row">
		<div class="col-lg-6">
			<img class="img-fluid rounded mb-4" src="http://placehold.it/750x450" alt=""> 
		</div>
		<div class="col-lg-6">
			<h2>
				My Profile 
			</h2>
			<p>
			<? 			
		    if($_SESSION["username"] == $_SESSION["split"][0]) {
			
			echo "Email: ".$_SESSION["split"][0];
			echo "<br>Description: ".$_SESSION["split"][2];
			
			
			}
			
			else if($_SESSION["username"] == $_SESSION["split"][3]){
			
			echo "Email: ".$_SESSION["split"][3];
			echo "<br>Description: ".$_SESSION["split"][5];
			
			
			} ?> 
			</p>
		</div>
	</div>
<!-- /.row -->
	<div class="row">
		<form method="post" action="/profile/updatePicture" enctype="multipart/form-data">
			<div class="form-group input-group">
				<div class="input-group-prepend">
				</div>
				<input name="myfile" type="file" class="form-control" placeholder="file"> 
			</div>
				<div class="form-group input-group">
					<input class="bg-success rounded" type="submit" value="Submit"> 
					</a>
				</div>
		</form>
	</div>
<!-- /.row -->
</div>
<!-- /.container -->
