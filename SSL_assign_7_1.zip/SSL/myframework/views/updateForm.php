  <!-- Page Content -->
  <div class="container">

    <!-- Page Heading/Breadcrumbs -->
    <h1 class="mt-4 mb-3">Crud
      <small>Subheading</small>
    </h1>

    <ol class="breadcrumb">
      <li class="breadcrumb-item">
      </li>
      
    </ol>

    <!-- Intro Content -->
    <div class="row">
      <div class="col-lg-6">
      <? 
     	$sql = "select * from users where id = :id";
		$data["users"] = $this->getModel("users")->select($sql, array(
		":id"=>$this->urlPathParts[2])); 
		?>
        <form action="/crud/update/<?echo $this->urlPathParts[2]?>" method="post">
        <h2>Update user</h2>
        <label for="updateemail" class="col-lg-4">Change email</label>
        <input type="text"  name="updateemail" placeholder="email" value="<?echo $data["users"][0]["email"] ?>">
        <label for="updatepass" class="col-lg-4">Change password</label>
        <input type="password" name="updatepass" placeholder="password"  value="<?echo $data["users"][0]["password"] ?>">
        <input type="submit">
        </form>
        
        
    </div>
    <!-- /.row -->

  </div>
  <!-- /.container -->