<?
//Part 1
class myclass{

public function myMethod(){

//Part 2
$name = "Trevor";
$age = 23;
$person = ["name"=>$name, "age"=>$age];

echo "Hello my name is $name and my age is $age <br>";

echo "Double quote: $name $age <br>";

echo 'Single quote: $name $age <br>';

echo "Indexes: ".$person[0], $person[1];

echo "Key/Value: ".$person["name"], $person["age"]."<br>";

$age = null;

echo "Age = null returns blank ($age)<br>";

unset ($name);

echo "Unset name: ".$name."<br>";

//Part 3

$numbers = [94, 54, 89.9, 60.01, 102.1];

for ($i = 0; $i < sizeOf($numbers, 0); $i++){

if($numbers[$i] > 90){
echo $numbers[$i]." = A<br>";
			}
	else if($numbers[$i] > 80){
		echo $numbers[$i]." = B<br>";
			}
	else if($numbers[$i] > 70){
		echo $numbers[$i]." = C<br>";
			}
	else if($numbers[$i] > 60){
		echo $numbers[$i]." = D<br>";
			}
	else {
		echo $numbers[$i]." = F<br>";
			}
		} //for

//Part 4

$colors = ["Red", "Ruby", "Blue", "Sapphire", "Yellow", "Lemon", "Green", "Emerald", "Orange", "Sunset"];

for ($i = 0; $i < sizeOf($colors, 0); $i++){
	
	echo "Index: $i, Color: $colors[$i]<br>";
		}
	} //method
} //class


$mynewclass = new myclass();
$mynewclass->myMethod();

?>