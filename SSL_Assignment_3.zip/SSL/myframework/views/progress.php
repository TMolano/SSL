  <html>
    <style>
    
    .assignment{
padding: 1rem;
padding-left: 0;
}

.assignment-list{
list-style: none;
}

    </style>
  </html>
  
  <!-- Page Content -->
  <div class="container">

    <!-- Page Heading/Breadcrumbs -->
    <h1 class="mt-4 mb-3">Progress
      <small>Subheading</small>
    </h1>

    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="index.html">Home</a>
      </li>
      <li class="breadcrumb-item">Progress</li>
    </ol>

    <!-- Intro Content -->
    <div class="row">
      <div class="col-lg-6">
      <ul class="assignment-list"
      <li class="assignment">Assignment 1
      	<div class="progress">
  			<div class="progress-bar bg-success" role="progressbar" style="width: 100%;" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
		</div>
	  </li>
	  <li class="assignment">Assignment 2
      	<div class="progress">
  			<div class="progress-bar bg-success" role="progressbar" style="width: 100%;" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>
		</div>
	  </li>
	  <li class="assignment">Assignment 3
      	<div class="progress">
  			<div class="progress-bar" role="progressbar" style="width: 75%;" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">75%</div>
		</div>
	  </li>
	  <li class="assignment">Assignment 4
      	<div class="progress">
  			<div class="progress-bar" role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
		</div>
	  </li>
	  <li class="assignment">Assignment 5
      	<div class="progress">
  			<div class="progress-bar" role="progressbar" style="width: %;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
		</div>
	  </li>
	  
	  <li class="assignment">
	  <!-- Button trigger modal -->
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
  Submit New Assignment
</button>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Upload New Assignment</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        Upload here...
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-danger" data-toggle="popover" title="Discard Files" data-content="Files will be discarded">Discard Files</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>
	  </li>
		
		</ul>
      </div>
    </div>
    <!-- /.row -->

  </div>
  <!-- /.container -->
  

