<?

class progress extends AppController{

  public function __construct($parent){

	$this->parent=$parent;
	
	}
	
	public function index(){
	
	$data = array();
	$data["pagename"] = "progress";
	$data["navigation"] = array("home"=>"/home", "about"=>"/about", "progress"=>"/progress");
	
	
	
	$this->parent->getView("header", $data);
	$this->parent->getView("progress");
	$this->parent->getView("footer");
	}
}

?>